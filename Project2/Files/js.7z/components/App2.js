import React, { Component } from 'react';
import ReactDOM from 'react-dom';

/*
const App2 = (props) => (
	<div>
		{props.children}
		<div> Hello, {props.Name}!</div>
	</div>
)


const App2 = ({children, Name}) => (
	<div>
		{children}
		<div> Hello, {Name}!!!</div>
	</div>
)
*/

class App2 extends Component{
	constructor (props){
		super(props);
	}
	render(){
		return (
			<div>
				{this.props.children}
				<div> Hello, {this.props.Name}!</div>
			</div>
		)
	}
}

App2.propTypes = {
 Name: React.PropTypes.string.isRequired
};

export default App2;