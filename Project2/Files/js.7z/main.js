/** Created by batmah on 16.10.16. */
import React from 'react';
import ReactDOM from 'react-dom';
//import App from './components/App';

import App2 from './components/App2';

/*ReactDOM.render(<App target="react" />, document.getElementById('app'));*/

ReactDOM.render(
	<App2 Name=" World">javaSchool</App2>,
	document.getElementById('app')
)